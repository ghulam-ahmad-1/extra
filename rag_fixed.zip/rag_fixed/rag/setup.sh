#!/bin/bash
# Quick start script for PDF RAG tool

set -e

echo "🚀 PDF RAG Tool - Quick Start Setup"
echo "==================================="

# 1. Create virtual environment
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# 2. Activate venv
echo "🔌 Activating virtual environment..."
source venv/bin/activate

# 3. Install dependencies
echo "📚 Installing dependencies..."
pip install -q -r requirements.txt

# 4. Setup .env
if [ ! -f ".env" ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please edit .env and add your GEMINI_API_KEY"
fi

# 5. Create data directories
mkdir -p data/uploads data/evaluation

echo ""
echo "✅ Setup complete!"
echo ""
echo "📖 Next steps:"
echo "1. Edit .env and add your Gemini API key"
echo "2. Run: streamlit run frontend/app.py"
echo ""
