"""Configuration management - simplified for local embeddings."""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load the .env file at the project root regardless of the directory the
# app was launched from. Previously load_dotenv() was never called anywhere
# in the project, so every value in .env was silently ignored and only real
# OS environment variables (or the hardcoded defaults below) ever applied.
load_dotenv(Path(__file__).resolve().parent.parent / ".env")


class Settings:
    """Simple application settings from environment variables."""
    
    # Embedding Model (Local Transformers)
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "BAAI/bge-large-en-v1.5")
    EMBEDDING_DEVICE: str = os.getenv("EMBEDDING_DEVICE", "cuda")  # or cpu
    
    # Vector Store
    VECTOR_STORE_DIR: str = os.getenv("VECTOR_STORE_DIR", ".rag_db")
    
    # Chunking
    CHUNK_SIZE_TOKENS: int = int(os.getenv("CHUNK_SIZE_TOKENS", "600"))
    CHUNK_OVERLAP_TOKENS: int = int(os.getenv("CHUNK_OVERLAP_TOKENS", "100"))
    
    # Retrieval
    RETRIEVAL_TOP_K: int = int(os.getenv("RETRIEVAL_TOP_K", "5"))
    RERANKING_TOP_K: int = int(os.getenv("RERANKING_TOP_K", "3"))
    
    # Optional: Gemini API (for answer generation)
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GENERATION_MODEL: str = os.getenv("GENERATION_MODEL", "gemini-2.5-flash")
    GENERATION_TEMPERATURE: float = float(os.getenv("GENERATION_TEMPERATURE", "0.2"))
    GENERATION_MAX_TOKENS: int = int(os.getenv("GENERATION_MAX_TOKENS", "1024"))


# Global settings instance
settings = Settings()


