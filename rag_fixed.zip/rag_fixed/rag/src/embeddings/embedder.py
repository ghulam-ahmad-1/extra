"""Embedding service using local transformers model (BAAI/bge-large-en-v1.5)."""

import logging
from typing import List
import os

logger = logging.getLogger(__name__)

# Global model cache
_embedder_cache = None


class LocalEmbedder:
    """Generate embeddings using local transformers model with caching."""
    
    def __init__(self, model_name: str = "BAAI/bge-large-en-v1.5"):
        """Initialize embedder with local model (loaded to cache)."""
        try:
            from sentence_transformers import SentenceTransformer
            
            # Set cache directory
            cache_dir = os.path.expanduser("~/.cache/huggingface/hub")
            os.makedirs(cache_dir, exist_ok=True)
            
            logger.info(f"Loading model: {model_name}")
            self.model = SentenceTransformer(
                model_name,
                cache_folder=cache_dir,
                device="cuda" if self._has_cuda() else "cpu"
            )
            self.embedding_dim = self.model.get_sentence_embedding_dimension()
            logger.info(f"Model loaded. Embedding dimension: {self.embedding_dim}")
            
        except Exception as e:
            logger.error(f"Error initializing embedder: {e}")
            raise
    
    @staticmethod
    def _has_cuda():
        """Check if CUDA is available."""
        try:
            import torch
            return torch.cuda.is_available()
        except:
            return False
    
    def embed_text(self, text: str) -> List[float]:
        """Generate embedding for single text."""
        try:
            embedding = self.model.encode(text, convert_to_tensor=False)
            return embedding.tolist()
        except Exception as e:
            logger.error(f"Error embedding text: {e}")
            raise
    
    def embed_batch(self, texts: List[str], batch_size: int = 32) -> List[List[float]]:
        """Generate embeddings for multiple texts with batching."""
        try:
            embeddings = self.model.encode(
                texts,
                batch_size=batch_size,
                convert_to_tensor=False,
                show_progress_bar=True
            )
            return embeddings.tolist()
        except Exception as e:
            logger.error(f"Error embedding batch: {e}")
            raise


def get_embedder(model_name: str = "BAAI/bge-large-en-v1.5") -> LocalEmbedder:
    """Get or create cached embedder instance."""
    global _embedder_cache
    
    if _embedder_cache is None:
        _embedder_cache = LocalEmbedder(model_name)
    
    return _embedder_cache
