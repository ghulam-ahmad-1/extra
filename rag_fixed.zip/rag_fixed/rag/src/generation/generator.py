"""Answer generation using the Gemini API.

Uses the new unified `google-genai` SDK (the same one your working test
script used: `from google import genai`). The previous version of this file
used `google-generativeai`, which Google has deprecated in favor of this
package - and used `gemini-2.0-flash`, which Google has since shut down on
the free tier (hence the `limit: 0` / 429 errors).
"""

import logging
import time
from typing import List, Dict

logger = logging.getLogger(__name__)


class AnswerGenerator:
    """Generate answers using Gemini with source citations."""

    SYSTEM_PROMPT = """You are a helpful assistant answering questions based on provided documents.
Rules:
1. Only use information from the provided context
2. Cite the source document for each fact
3. Quote exact values from tables, do not paraphrase numbers
4. If information is not in context, say so clearly
5. Be concise but thorough"""

    def __init__(self, api_key: str, model: str = "gemini-2.5-flash"):
        """Initialize the Gemini client."""
        try:
            from google import genai
            self.client = genai.Client(api_key=api_key)
            self.model_name = model
            logger.info(f"Gemini generator initialized with {model}")
        except Exception as e:
            logger.error(f"Error initializing generator: {e}")
            raise

    def generate(
        self,
        query: str,
        search_results: List[Dict],
        temperature: float = 0.2,
        max_tokens: int = 1024,
        max_retries: int = 2,
    ) -> Dict:
        """
        Generate answer from search results.

        Retries a couple of times with backoff on a 429 - this covers the
        transient "requests per minute" kind of rate limit. A genuine daily
        quota exhaustion will still fail after retries, with a clearer
        message instead of a raw stack trace.
        """
        from google.genai import types
        from google.genai.errors import APIError

        context_text = self._build_context(search_results)
        user_prompt = f"""Context documents:
{context_text}

Question: {query}

Provide a detailed answer citing sources."""

        delay = 2
        last_error: Exception = None

        for attempt in range(max_retries + 1):
            try:
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=user_prompt,
                    config=types.GenerateContentConfig(
                        system_instruction=self.SYSTEM_PROMPT,
                        temperature=temperature,
                        max_output_tokens=max_tokens,
                    ),
                )
                return {
                    "answer": response.text,
                    "sources": self._extract_sources(search_results),
                    "model": self.model_name,
                }
            except APIError as e:
                last_error = e
                is_429 = getattr(e, "code", None) == 429 or "429" in str(e)
                if is_429 and attempt < max_retries:
                    logger.warning(f"Gemini 429, retrying in {delay}s (attempt {attempt + 1})")
                    time.sleep(delay)
                    delay *= 2
                    continue
                break
            except Exception as e:
                last_error = e
                break

        logger.error(f"Error generating answer: {last_error}")
        message = str(last_error)
        if "429" in message or "quota" in message.lower():
            message = (
                "Gemini rate limit / quota exceeded for this model. If this "
                "is a per-minute limit it should clear in under a minute; if "
                "it's a daily quota you'll need to wait for reset or switch "
                "GENERATION_MODEL in .env to a model with free-tier headroom. "
                f"Raw error: {message}"
            )
        return {
            "answer": f"Error: {message}",
            "sources": [],
            "model": self.model_name,
        }

    def _build_context(self, search_results: List[Dict]) -> str:
        """Build context string from search results."""
        context_parts = []

        for i, result in enumerate(search_results, 1):
            source = result.get("metadata", {}).get("source_file", "Unknown")
            page = result.get("metadata", {}).get("page_number", "?")
            is_table = result.get("metadata", {}).get("is_table") == "True"
            content = result.get("content", "")

            marker = "📊 TABLE" if is_table else "📝 TEXT"
            context_parts.append(
                f"[{i}] {marker} - {source} (Page {page}):\n{content}\n"
            )

        return "\n---\n".join(context_parts)

    def _extract_sources(self, search_results: List[Dict]) -> List[Dict]:
        """Extract source information from results."""
        sources = []

        for result in search_results:
            source_info = {
                "document": result.get("metadata", {}).get("source_file", "Unknown"),
                "page": result.get("metadata", {}).get("page_number", "?"),
                "type": result.get("metadata", {}).get("chunk_type", "text"),
                "is_table": result.get("metadata", {}).get("is_table") == "True",
            }

            if source_info not in sources:
                sources.append(source_info)

        return sources
