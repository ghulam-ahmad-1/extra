"""Simple PDF ingestion and parsing."""

import logging
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger(__name__)


class PDFParser:
    """Simple PDF parser using pymupdf4llm, with accurate per-page markdown."""

    def parse_pdf(self, pdf_path: str) -> Dict:
        """
        Parse PDF and extract markdown content, page by page.

        Args:
            pdf_path: Path to PDF file

        Returns:
            Dictionary with:
                filename: original file name
                content: full document markdown (all pages joined, for display/debug)
                pages: List[{"page_number": int, "text": str}] - one entry per PDF
                        page, used downstream so chunks/citations get the *real*
                        page number instead of always being tagged "page 1".
                num_pages: total page count
        """
        pdf_path = Path(pdf_path)
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        logger.info(f"Parsing PDF: {pdf_path}")

        try:
            import pymupdf4llm
            # page_chunks=True returns a list of per-page dicts instead of one
            # giant string, so we can keep an accurate page_number per chunk.
            page_data = pymupdf4llm.to_markdown(str(pdf_path), page_chunks=True)
        except Exception as e:
            logger.error(f"Error parsing PDF: {e}")
            raise

        pages: List[Dict] = []
        for i, page in enumerate(page_data, start=1):
            text = page.get("text", "") if isinstance(page, dict) else str(page)
            pages.append({"page_number": i, "text": text})

        full_content = "\n\n".join(p["text"] for p in pages)

        return {
            "filename": pdf_path.name,
            "content": full_content,
            "pages": pages,
            "num_pages": len(pages),
        }
