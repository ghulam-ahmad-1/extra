"""Persistent vector store using ChromaDB.

NOTE ON THE FILE NAME: this module is actually backed by ChromaDB, not Qdrant
(the docstring/class always said ChromaDB - the filename is just a leftover
from an earlier draft that used Qdrant and was never renamed). Left as-is for
now so existing imports don't break; rename together with its import in
frontend/app.py if you want it cleaned up.
"""

import logging
import json
from typing import List, Dict
from pathlib import Path

logger = logging.getLogger(__name__)


class PersistentVectorStore:
    """Persistent vector store using ChromaDB with disk persistence."""

    def __init__(self, db_dir: str = ".rag_db"):
        """Initialize persistent vector store."""
        self.db_dir = Path(db_dir)
        self.db_dir.mkdir(parents=True, exist_ok=True)
        self.chunks_file = self.db_dir / "chunks_metadata.json"

        try:
            import chromadb

            # chromadb>=0.4 removed the old Settings(chroma_db_impl=...,
            # persist_directory=...) + Client(settings) combo (it now raises
            # a config error). PersistentClient is the current, correct way
            # to get an on-disk, persistent collection.
            self.client = chromadb.PersistentClient(path=str(self.db_dir / "chroma"))
            self.collection = self.client.get_or_create_collection(
                name="pdf_rag",
                metadata={"hnsw:space": "cosine"}
            )

            logger.info(f"Vector store initialized at {self.db_dir}")

        except Exception as e:
            logger.error(f"Error initializing ChromaDB: {e}")
            raise

        # Sidecar metadata (lets us list documents / show stats without
        # querying the vector index itself).
        self.chunks_metadata = {}
        self._load_metadata()

    def _load_metadata(self):
        """Load existing chunks metadata."""
        if self.chunks_file.exists():
            try:
                with open(self.chunks_file, 'r') as f:
                    self.chunks_metadata = json.load(f)
                logger.info(f"Loaded {len(self.chunks_metadata)} chunks from metadata")
            except Exception as e:
                logger.warning(f"Could not load metadata: {e}")

    def _save_metadata(self):
        """Save chunks metadata to disk."""
        try:
            with open(self.chunks_file, 'w') as f:
                json.dump(self.chunks_metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving metadata: {e}")

    def add_chunks(self, chunks: List[Dict], embeddings: List[List[float]]) -> None:
        """Add chunks with embeddings to store."""
        try:
            ids = []
            documents = []
            metadatas = []

            for chunk in chunks:
                chunk_id = f"{chunk.get('source_file', 'unknown')}_{len(self.chunks_metadata)}"
                ids.append(chunk_id)

                # Store full chunk content with summary if available
                content = chunk.get("content_with_summary", chunk.get("content", ""))
                documents.append(content)

                # Rich metadata (Chroma only stores str/int/float/bool, hence the str())
                metadata = {
                    "source_file": chunk.get("source_file", "unknown"),
                    "page_number": str(chunk.get("page_number", 0)),
                    "chunk_type": chunk.get("chunk_type", "text"),
                    "is_table": str(chunk.get("metadata", {}).get("is_table", False)),
                }
                metadatas.append(metadata)

                # Store chunk info
                self.chunks_metadata[chunk_id] = {
                    "content": chunk.get("content", ""),
                    "summary": chunk.get("summary"),
                    "source_file": chunk.get("source_file"),
                    "page_number": chunk.get("page_number"),
                    "chunk_type": chunk.get("chunk_type"),
                    "is_table": chunk.get("metadata", {}).get("is_table", False),
                }

            # Add to ChromaDB
            self.collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=documents,
                metadatas=metadatas,
            )

            # Save metadata
            self._save_metadata()

            logger.info(f"Added {len(chunks)} chunks to vector store")

        except Exception as e:
            logger.error(f"Error adding chunks: {e}")
            raise

    def search(self, query_embedding: List[float], top_k: int = 5) -> List[Dict]:
        """Search for similar chunks."""
        try:
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
            )

            if not results or not results['ids'] or not results['ids'][0]:
                return []

            # Format results with metadata
            formatted_results = []
            for i, chunk_id in enumerate(results['ids'][0]):
                formatted_results.append({
                    "id": chunk_id,
                    "content": results['documents'][0][i],
                    "distance": results['distances'][0][i],
                    "metadata": results['metadatas'][0][i],
                    "chunk_info": self.chunks_metadata.get(chunk_id, {}),
                })

            return formatted_results

        except Exception as e:
            logger.error(f"Error searching: {e}")
            raise

    def get_documents(self) -> List[str]:
        """Get list of indexed documents."""
        try:
            unique_files = set()
            for info in self.chunks_metadata.values():
                unique_files.add(info.get("source_file"))
            return list(filter(None, unique_files))
        except Exception as e:
            logger.error(f"Error getting documents: {e}")
            return []

    def get_document_stats(self) -> Dict[str, Dict]:
        """Per-document stats (page count, chunk/table counts) so the UI can
        show something useful for documents reloaded from a previous session."""
        stats: Dict[str, Dict] = {}
        try:
            for info in self.chunks_metadata.values():
                source_file = info.get("source_file")
                if not source_file:
                    continue
                entry = stats.setdefault(source_file, {"chunks": 0, "tables": 0, "max_page": 0})
                entry["chunks"] += 1
                if info.get("is_table"):
                    entry["tables"] += 1
                page = info.get("page_number") or 0
                try:
                    entry["max_page"] = max(entry["max_page"], int(page))
                except (TypeError, ValueError):
                    pass
        except Exception as e:
            logger.error(f"Error computing document stats: {e}")
        return stats

    def clear(self) -> None:
        """Clear the vector store."""
        try:
            # Delete and recreate collection
            self.client.delete_collection("pdf_rag")
            self.collection = self.client.get_or_create_collection(
                name="pdf_rag",
                metadata={"hnsw:space": "cosine"}
            )
            self.chunks_metadata = {}
            self._save_metadata()
            logger.info("Vector store cleared")
        except Exception as e:
            logger.error(f"Error clearing store: {e}")
            raise
