"""Intelligent chunking with table extraction."""

import logging
import re
from typing import List, Dict, Tuple

logger = logging.getLogger(__name__)


class TableExtractor:
    """Extract and preserve *complete* markdown tables (header + separator +
    every data row) as atomic chunks, so numbers never get split mid-table."""

    # A table row: starts and ends with '|'.
    _ROW_RE = re.compile(r'^\s*\|.*\|\s*$')
    # The header/body separator row, e.g. "| --- | :--- | ---: |"
    _SEPARATOR_RE = re.compile(r'^\s*\|?[\s:\-]+(\|[\s:\-]+)*\|?\s*$')

    @classmethod
    def extract_tables_from_markdown(cls, text: str) -> Tuple[List[Dict], str]:
        """
        Walk the text line by line. Whenever a row is immediately followed by
        a valid separator row, treat that as the start of a table and keep
        consuming every following row-shaped line as part of the SAME table.

        Returns:
            (tables_list, text_without_tables)
        """
        lines = text.split('\n')
        tables: List[Dict] = []
        kept_lines: List[str] = []
        i, n = 0, len(lines)

        while i < n:
            line = lines[i]
            is_header = bool(cls._ROW_RE.match(line))
            has_separator_next = (
                i + 1 < n
                and bool(cls._SEPARATOR_RE.match(lines[i + 1]))
                and '-' in lines[i + 1]
            )

            if is_header and has_separator_next:
                table_lines = [line, lines[i + 1]]
                j = i + 2
                # Keep pulling in every subsequent data row (this is the part
                # the old regex-only version missed entirely).
                while j < n and cls._ROW_RE.match(lines[j]):
                    table_lines.append(lines[j])
                    j += 1

                tables.append({
                    "content": "\n".join(table_lines).strip(),
                    "type": "markdown_table",
                })
                i = j
            else:
                kept_lines.append(line)
                i += 1

        text_without_tables = "\n".join(kept_lines)
        return tables, text_without_tables


class TextChunker:
    """Intelligent text chunker with table handling and real word-overlap."""

    def __init__(self, chunk_size: int = 600, overlap: int = 100):
        """Initialize chunker."""
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.table_extractor = TableExtractor()

    def chunk_document(self, pages: List[Dict], source_file: str) -> List[Dict]:
        """
        Smart chunking across a full document: tables are extracted per-page
        (so each table chunk keeps its real page number), then remaining text
        on that page is chunked normally.

        Args:
            pages: List of {"page_number": int, "text": str}, one per PDF page
                   (as produced by PDFParser.parse_pdf).
            source_file: Source filename

        Returns:
            List of chunks (both text and table chunks), each correctly
            tagged with chunk_type, page_number and metadata.
        """
        chunks: List[Dict] = []
        total_tables = 0

        for page in pages:
            page_number = page.get("page_number", 1)
            page_text = page.get("text", "")

            tables, text_without_tables = self.table_extractor.extract_tables_from_markdown(page_text)
            total_tables += len(tables)

            for table in tables:
                chunks.append({
                    "content": table["content"],
                    "source_file": source_file,
                    "page_number": page_number,
                    "chunk_type": "table",
                    "metadata": {
                        "is_table": True,
                        "preserve": True,  # Never split tables
                    }
                })

            chunks.extend(self.chunk_text(text_without_tables, source_file, page_number))

        logger.info(
            f"Created {len(chunks)} chunks ({total_tables} tables, "
            f"{len(chunks) - total_tables} text)"
        )
        return chunks

    def chunk_text(self, text: str, source_file: str, page_number: int = 1) -> List[Dict]:
        """
        Split text into chunks by paragraph, carrying the trailing
        `self.overlap` words of one chunk into the start of the next so
        context isn't lost at chunk boundaries.

        Args:
            text: Text to chunk
            source_file: Source filename
            page_number: Page number

        Returns:
            List of text chunks with metadata
        """
        if not text.strip():
            return []

        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        chunks: List[Dict] = []
        current_paras: List[str] = []
        current_word_count = 0

        def flush():
            content = "\n\n".join(current_paras).strip()
            if content:
                chunks.append({
                    "content": content,
                    "source_file": source_file,
                    "page_number": page_number,
                    "chunk_type": "text",
                    "metadata": {
                        "is_table": False,
                    }
                })

        for para in paragraphs:
            para_word_count = len(para.split())

            if current_paras and current_word_count + para_word_count > self.chunk_size:
                flush()
                overlap_text = self._tail_words(current_paras, self.overlap)
                current_paras = [overlap_text] if overlap_text else []
                current_word_count = len(overlap_text.split())

            current_paras.append(para)
            current_word_count += para_word_count

        flush()
        return chunks

    @staticmethod
    def _tail_words(paras: List[str], n: int) -> str:
        """Return the last `n` words across the given paragraphs, joined."""
        if n <= 0:
            return ""
        words = "\n\n".join(paras).split()
        return " ".join(words[-n:])

    def add_summary_to_table(self, table_chunk: Dict, summary: str) -> Dict:
        """Add AI-generated summary to table chunk for better retrieval."""
        table_chunk["summary"] = summary
        table_chunk["content_with_summary"] = f"Summary: {summary}\n\n{table_chunk['content']}"
        return table_chunk
