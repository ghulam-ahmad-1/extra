"""Simple retrieval with reranking."""

import logging
from typing import List, Dict

logger = logging.getLogger(__name__)


class SimpleRetrieval:
    """Simple retrieval with optional reranking."""
    
    def __init__(self, vector_store=None, embedder=None, genai_model=None):
        """Initialize retrieval."""
        self.vector_store = vector_store
        self.embedder = embedder
        self.genai_model = genai_model
    
    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        use_reranking: bool = False,
    ) -> List[Dict]:
        """Retrieve relevant chunks."""
        if not self.embedder or not self.vector_store:
            logger.error("Vector store or embedder not initialized")
            return []
        
        try:
            # Embed query
            query_embedding = self.embedder.embed_text(query)
            
            # Search vector store
            chunks = self.vector_store.search(query_embedding, top_k=top_k * 2)
            
            # Optionally rerank
            if use_reranking and self.genai_model:
                chunks = self._rerank(query, chunks, top_k)
            else:
                chunks = chunks[:top_k]
            
            return chunks
        except Exception as e:
            logger.error(f"Error retrieving chunks: {e}")
            return []
    
    def _rerank(self, query: str, chunks: List[Dict], top_k: int) -> List[Dict]:
        """Rerank chunks using Gemini."""
        try:
            if len(chunks) <= top_k:
                return chunks
            
            # Create reranking prompt
            candidate_text = "\n\n".join([
                f"[{i}] {chunk['content'][:200]}"
                for i, chunk in enumerate(chunks)
            ])
            
            prompt = f"""Rank these passages by relevance to the question.
Return ONLY the ranking as numbers (e.g., "3, 1, 5, 2").

Question: {query}

Passages:
{candidate_text}

Ranking:"""
            
            response = self.genai_model.generate_content(prompt)
            ranking = response.text
            
            # Parse ranking
            try:
                indices = [int(x.strip()) - 1 for x in ranking.split(',')]
                ranked_chunks = [chunks[i] for i in indices if 0 <= i < len(chunks)]
                return ranked_chunks[:top_k] if ranked_chunks else chunks[:top_k]
            except:
                return chunks[:top_k]
        except Exception as e:
            logger.error(f"Error reranking: {e}")
            return chunks[:top_k]
