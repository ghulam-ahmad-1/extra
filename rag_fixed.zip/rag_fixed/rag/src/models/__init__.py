"""Pydantic models for RAG system."""

from typing import Optional
from datetime import datetime
from pydantic import BaseModel, Field


class ChunkMetadata(BaseModel):
    """Metadata associated with a chunk."""
    source_file: str
    page_number: int
    chunk_type: str  # "text" or "table"
    chunk_index: int
    nearby_heading: Optional[str] = None
    summary: str  # Contextual 1-sentence summary


class Chunk(BaseModel):
    """Document chunk with embeddings ready state."""
    id: str
    document_id: str
    content: str
    metadata: ChunkMetadata
    embedding: Optional[list[float]] = None
    token_count: int


class Document(BaseModel):
    """Uploaded PDF document metadata."""
    id: str
    filename: str
    upload_date: datetime
    file_size: int  # bytes
    pages: int
    status: str  # "uploaded", "processing", "completed", "failed"
    error_message: Optional[str] = None
    processed_chunks: int = 0
    s3_key: str  # Path in S3/MinIO


class SearchRequest(BaseModel):
    """User query for RAG system."""
    query: str = Field(..., min_length=3, max_length=500)
    document_ids: Optional[list[str]] = None  # Filter to specific docs
    top_k: int = Field(default=5, ge=1, le=20)
    filters: Optional[dict] = None  # e.g., {"page_number": [1, 5]}
    use_reranking: bool = True


class RetrievedChunk(BaseModel):
    """Single search result."""
    chunk_id: str
    content: str
    metadata: ChunkMetadata
    relevance_score: float
    search_type: str  # "vector", "keyword", "hybrid"


class SearchResult(BaseModel):
    """Result of hybrid search."""
    query: str
    chunks: list[RetrievedChunk]
    total_results: int
    search_time_ms: float


class GeneratedAnswer(BaseModel):
    """Final RAG answer with citations."""
    query: str
    answer: str
    sources: list[dict]  # [{document: str, page: int, quote: str}, ...]
    confidence: float  # 0.0 to 1.0
    retrieval_results: SearchResult


class ProcessDocumentRequest(BaseModel):
    """Request to process an uploaded PDF."""
    document_id: str
    use_docling: bool = False  # Use docling instead of pymupdf4llm


class HealthResponse(BaseModel):
    """API health status."""
    status: str
    version: str
    services: dict  # {service_name: is_healthy}
