"""Advanced Streamlit RAG app - persistent, multi-file, table-aware."""

import os
import sys
from pathlib import Path
from typing import List, Dict

import streamlit as st

# Project paths (resolved relative to this file, NOT the current working
# directory - this matters because Streamlit can be launched from anywhere).
PROJECT_ROOT = Path(__file__).parent.parent
SRC_DIR = PROJECT_ROOT / "src"
UPLOADS_DIR = PROJECT_ROOT / "data" / "uploads"

sys.path.insert(0, str(SRC_DIR))

from config import settings
from ingestion.parser import PDFParser
from chunking.chunker import TextChunker
from embeddings.embedder import get_embedder
from vector_store.qdrant_client import PersistentVectorStore
from generation.generator import AnswerGenerator


def init_session_state():
    """Initialize session state."""
    if "vector_store" not in st.session_state:
        st.session_state.vector_store = None
    if "embedder" not in st.session_state:
        st.session_state.embedder = None
    if "generator" not in st.session_state:
        st.session_state.generator = None
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "documents" not in st.session_state:
        st.session_state.documents = {}


def init_components():
    """Initialize RAG components (with caching)."""
    with st.spinner("Initializing components..."):
        try:
            # Get cached embedder
            if st.session_state.embedder is None:
                st.session_state.embedder = get_embedder(settings.EMBEDDING_MODEL)

            # Initialize vector store
            if st.session_state.vector_store is None:
                vector_store_path = PROJECT_ROOT / settings.VECTOR_STORE_DIR
                st.session_state.vector_store = PersistentVectorStore(str(vector_store_path))

                # Load existing documents (with real stats, not empty dicts)
                existing_docs = st.session_state.vector_store.get_documents()
                doc_stats = st.session_state.vector_store.get_document_stats()
                if existing_docs:
                    st.session_state.documents = {
                        doc: doc_stats.get(doc, {}) for doc in existing_docs
                    }

            # Initialize generator (using Gemini if API key available)
            if st.session_state.generator is None:
                api_key = os.getenv("GEMINI_API_KEY") or settings.GEMINI_API_KEY
                if api_key:
                    try:
                        st.session_state.generator = AnswerGenerator(
                            api_key, model=settings.GENERATION_MODEL
                        )
                    except Exception as e:
                        st.warning(f"Could not initialize Gemini generator: {e}")
                else:
                    st.info("No Gemini API key set yet - answers will fall back to raw retrieved text.")

            st.success("✅ Components loaded!")
            return True

        except Exception as e:
            st.error(f"Error initializing: {str(e)}")
            return False


def process_pdf(uploaded_file) -> Dict:
    """Save the uploaded PDF persistently, parse it, chunk it, embed it, and
    add it to the vector store."""
    try:
        # Persist the original PDF to disk (data/uploads) instead of a
        # throwaway tempfile, so it's still available in future sessions.
        UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
        dest_path = UPLOADS_DIR / uploaded_file.name
        with open(dest_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        # Parse (returns per-page markdown, not just one flat blob)
        parser = PDFParser()
        pdf_data = parser.parse_pdf(str(dest_path))

        # Chunk with table awareness, using real page numbers
        chunker = TextChunker(
            chunk_size=settings.CHUNK_SIZE_TOKENS,
            overlap=settings.CHUNK_OVERLAP_TOKENS,
        )
        chunks = chunker.chunk_document(pdf_data["pages"], source_file=uploaded_file.name)

        if not chunks:
            return {
                "success": False,
                "message": f"⚠️ No extractable text found in {uploaded_file.name}",
                "details": None,
            }

        # Generate embeddings
        embeddings = st.session_state.embedder.embed_batch(
            [c["content"] for c in chunks]
        )

        # Add to persistent store
        st.session_state.vector_store.add_chunks(chunks, embeddings)
        st.session_state.documents[uploaded_file.name] = {
            "max_page": pdf_data["num_pages"],
            "chunks": len(chunks),
            "tables": sum(1 for c in chunks if c["chunk_type"] == "table"),
        }

        num_tables = sum(1 for c in chunks if c["chunk_type"] == "table")
        return {
            "success": True,
            "message": f"✅ Loaded {uploaded_file.name}",
            "details": f"{pdf_data['num_pages']} pages, {len(chunks)} chunks ({num_tables} tables)",
        }

    except Exception as e:
        return {
            "success": False,
            "message": f"❌ Error: {str(e)}",
            "details": None,
        }


def search_rag(query: str, top_k: int = 5) -> List[Dict]:
    """Search the RAG database."""
    try:
        query_embedding = st.session_state.embedder.embed_text(query)
        return st.session_state.vector_store.search(query_embedding, top_k=top_k)
    except Exception as e:
        st.error(f"Search error: {str(e)}")
        return []


def generate_answer(query: str, search_results: List[Dict]) -> str:
    """Generate answer from search results."""
    if not st.session_state.generator:
        # Simple fallback if no generator
        context = "\n\n".join([r["content"] for r in search_results])
        return f"**Answer based on retrieval (no Gemini key set):**\n\n{context}"

    try:
        answer = st.session_state.generator.generate(query, search_results)
        return answer.get("answer", "Could not generate answer")
    except Exception as e:
        return f"Generation error: {str(e)}"


def main():
    st.set_page_config(page_title="Advanced PDF RAG", layout="wide")
    st.title("📚 Advanced PDF RAG System")
    st.markdown("**Persistent • Multi-file • Table-aware • Local Embeddings**")

    init_session_state()

    # Sidebar
    with st.sidebar:
        st.header("⚙️ Configuration")

        if st.button("🔧 Initialize Components", use_container_width=True):
            if init_components():
                st.rerun()

        if not st.session_state.embedder:
            st.warning("⚠️ Click 'Initialize' to load components")
            st.stop()

        # Gemini API (optional for generation)
        with st.expander("🔑 Gemini API (Optional)"):
            api_key_input = st.text_input("API Key", type="password", key="gemini_key")
            if api_key_input and st.button("Apply key", key="apply_gemini_key"):
                os.environ["GEMINI_API_KEY"] = api_key_input
                try:
                    st.session_state.generator = AnswerGenerator(
                        api_key_input, model=settings.GENERATION_MODEL
                    )
                    st.success("Gemini generator ready.")
                except Exception as e:
                    st.error(f"Could not initialize Gemini: {e}")

        st.divider()

        # Document management
        st.subheader("📁 Documents")

        col_docs = st.columns([3, 1])
        with col_docs[0]:
            if st.button("🗑️ Clear All", use_container_width=True):
                st.session_state.vector_store.clear()
                st.session_state.documents = {}
                st.success("Database cleared!")
                st.rerun()

        with col_docs[1]:
            st.metric("Docs", len(st.session_state.documents))

        # Document list with stats
        if st.session_state.documents:
            st.markdown("**Indexed Documents:**")
            for doc_name, info in st.session_state.documents.items():
                pages = info.get("max_page")
                chunks = info.get("chunks")
                caption = f"📄 {doc_name}"
                if pages or chunks:
                    caption += f" ({pages or '?'} pages, {chunks or '?'} chunks)"
                st.caption(caption)

    # Main content
    col1, col2 = st.columns([1, 2])

    with col1:
        st.subheader("📤 Upload PDFs")

        uploaded_files = st.file_uploader(
            "Add PDFs to RAG",
            type="pdf",
            accept_multiple_files=True,
            key="pdf_uploader"
        )

        if uploaded_files:
            newly_processed = False
            for file in uploaded_files:
                if file.name not in st.session_state.documents:
                    with st.spinner(f"Processing {file.name}..."):
                        result = process_pdf(file)
                        if result["success"]:
                            st.success(result["message"])
                            if result["details"]:
                                st.caption(result["details"])
                        else:
                            st.error(result["message"])
                        newly_processed = True

            # Only rerun if something actually changed - otherwise this loops
            # forever, since the uploader keeps the files attached on every
            # rerun even after they've already been indexed.
            if newly_processed:
                st.rerun()

    with col2:
        st.subheader("💬 Ask Questions")

        if not st.session_state.documents:
            st.info("👈 Upload PDFs to start asking questions")
        else:
            query = st.text_area(
                "Your question:",
                placeholder="Ask anything about your documents...",
                height=100,
                key="query_input"
            )

            col_search = st.columns([3, 1])

            with col_search[0]:
                search_btn = st.button("🔍 Search & Answer", use_container_width=True)

            with col_search[1]:
                top_k = st.number_input("Results", 1, 20, settings.RETRIEVAL_TOP_K)

            if search_btn and query:
                with st.spinner("Searching..."):
                    search_results = search_rag(query, top_k=top_k)

                    if search_results:
                        with st.expander(f"📑 Retrieved {len(search_results)} chunks"):
                            for i, result in enumerate(search_results, 1):
                                st.markdown(f"**Chunk {i}** (Distance: {result['distance']:.3f})")

                                if result["metadata"].get("is_table") == "True":
                                    st.markdown("🔶 **TABLE**")

                                st.markdown(f"*From: {result['metadata'].get('source_file')} "
                                            f"(Page {result['metadata'].get('page_number')})*")
                                st.markdown(f"```\n{result['content'][:500]}...\n```")
                                st.divider()

                        with st.spinner("Generating answer..."):
                            answer = generate_answer(query, search_results)
                            st.markdown("### 📝 Answer")
                            st.markdown(answer)
                    else:
                        st.warning("No relevant chunks found")

                    st.session_state.chat_history.append({
                        "query": query,
                        "results": len(search_results),
                    })

            if st.session_state.chat_history:
                st.divider()
                with st.expander("📜 Query History"):
                    for item in st.session_state.chat_history[-5:]:
                        st.caption(f"Q: {item['query'][:60]}... ({item['results']} results)")


if __name__ == "__main__":
    main()
