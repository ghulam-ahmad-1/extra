"""
ingest.py
---------
Full ingestion pipeline matching the workflow:

  PDF  →  Docling (MinerU-style conversion)  →  Markdown
       →  Chunking
       →  BGE-small embeddings  +  Gemini entity/relationship extraction
       →  Vector DB  +  Knowledge Graph
       →  LightRAG storage

Run once before starting the Streamlit app:
    python ingest.py
"""

import asyncio
import json
import os
from pathlib import Path

from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.pipeline_options import PdfPipelineOptions

from rag_engine import get_rag, chunk_text

# ------------------------------------------------------------------
# Config
# ------------------------------------------------------------------

DOCS_DIR = Path("data/documents")
STORAGE_DIR = Path("storage")
INGESTED_LOG = STORAGE_DIR / "ingested_files.json"


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def load_ingested_log() -> set[str]:
    """Return the set of already-ingested file names (idempotency guard)."""
    if INGESTED_LOG.exists():
        with open(INGESTED_LOG) as f:
            return set(json.load(f))
    return set()


def save_ingested_log(names: set[str]) -> None:
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    with open(INGESTED_LOG, "w") as f:
        json.dump(sorted(names), f, indent=2)


def build_converter() -> DocumentConverter:
    """
    Build a Docling DocumentConverter with OCR-capable PDF options,
    mirroring MinerU-style high-fidelity PDF parsing.
    """
    pipeline_options = PdfPipelineOptions()
    pipeline_options.do_ocr = True            # handle scanned pages
    pipeline_options.do_table_structure = True  # extract tables as markdown

    return DocumentConverter(
        format_options={
            "pdf": PdfFormatOption(pipeline_options=pipeline_options)
        }
    )


# ------------------------------------------------------------------
# Main ingestion coroutine
# ------------------------------------------------------------------

async def ingest_documents() -> None:
    if not DOCS_DIR.exists() or not any(DOCS_DIR.iterdir()):
        print(f"[ingest] No documents found in {DOCS_DIR}. Nothing to do.")
        return

    rag = await get_rag()
    converter = build_converter()
    ingested = load_ingested_log()

    files = [
        f for f in sorted(DOCS_DIR.iterdir())
        if f.is_file() and f.suffix.lower() in {".pdf", ".docx", ".pptx", ".html", ".md", ".txt"}
    ]

    if not files:
        print(f"[ingest] No supported files in {DOCS_DIR}.")
        return

    newly_ingested: list[str] = []

    for file in files:
        if file.name in ingested:
            print(f"[ingest] Skipping (already indexed): {file.name}")
            continue

        print(f"\n[ingest] ── Processing: {file.name}")

        # ── Step 1: PDF → Markdown (Docling / MinerU-style) ──────────
        print(f"  [1/3] Converting to Markdown via Docling …")
        try:
            result = converter.convert(str(file))
            markdown_text = result.document.export_to_markdown()
        except Exception as exc:
            print(f"  [!] Docling conversion failed for {file.name}: {exc}")
            continue

        if not markdown_text.strip():
            print(f"  [!] Empty markdown output for {file.name}. Skipping.")
            continue

        print(f"  [1/3] Markdown length: {len(markdown_text):,} chars")

        # ── Step 2: Chunking ──────────────────────────────────────────
        print(f"  [2/3] Chunking …")
        chunks = chunk_text(markdown_text, chunk_size=1200, overlap=200)
        print(f"  [2/3] {len(chunks)} chunk(s) created")

        # ── Step 3: Insert into LightRAG ──────────────────────────────
        # LightRAG internally runs:
        #   • BGE-small → vector embeddings → vector DB
        #   • Gemini Flash → entity + relationship extraction → KG
        print(f"  [3/3] Inserting into LightRAG (embeddings + KG extraction) …")
        try:
            # Insert all chunks as a batch; LightRAG deduplicates internally
            for i, chunk in enumerate(chunks, 1):
                await rag.ainsert(chunk)
                if i % 10 == 0 or i == len(chunks):
                    print(f"  [3/3] {i}/{len(chunks)} chunks inserted …")
        except Exception as exc:
            print(f"  [!] Insertion error for {file.name}: {exc}")
            continue

        newly_ingested.append(file.name)
        ingested.add(file.name)
        print(f"  ✓ Done: {file.name}")

    save_ingested_log(ingested)

    if newly_ingested:
        print(f"\n[ingest] ✅ Finished. Indexed {len(newly_ingested)} new file(s):")
        for name in newly_ingested:
            print(f"    • {name}")
    else:
        print("\n[ingest] ✅ All files already indexed. Nothing new to process.")


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------

if __name__ == "__main__":
    asyncio.run(ingest_documents())
