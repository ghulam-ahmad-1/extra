"""
app.py
------
Streamlit UI for the LightRAG + Gemini pipeline.

Workflow (displayed in sidebar):
  PDF → Docling → Markdown → Chunking
      → BGE-small (embeddings) + Gemini Flash (entity/rel extraction)
      → Vector DB + Knowledge Graph
      → LightRAG Engine
      → Hybrid Retrieval + KG
      → Gemini Flash answer
      → User

Run:
    streamlit run app.py
"""

import asyncio
import os
import sys
from pathlib import Path

import streamlit as st

# ------------------------------------------------------------------
# Page config (must be first Streamlit call)
# ------------------------------------------------------------------

st.set_page_config(
    page_title="LightRAG Assistant",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------------------------------------------------
# Asyncio compatibility fix for Streamlit
# Streamlit runs inside its own thread/event-loop; we need a fresh
# loop per query instead of re-using a closed one.
# ------------------------------------------------------------------

def run_async(coro):
    """Run an async coroutine safely inside Streamlit."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("closed")
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)


# ------------------------------------------------------------------
# Lazy imports (avoid slow imports on every rerun)
# ------------------------------------------------------------------

@st.cache_resource(show_spinner="Loading LightRAG engine …")
def load_rag():
    """Load RAG engine once and cache across reruns."""
    from rag_engine import get_rag
    return run_async(get_rag())


# ------------------------------------------------------------------
# Sidebar — pipeline overview + controls
# ------------------------------------------------------------------

with st.sidebar:
    st.title("⚙️ Pipeline")

    st.markdown("""
```
PDF / Documents
      │
      ▼
 Docling / MinerU
      │
      ▼
   Markdown
      │
      ▼
   Chunking
      │
   ┌──┴──┐
   ▼     ▼
BGE-small  Gemini Flash
   ▼          ▼
 Vector   Entity + Rel
   DB     Extraction
   │          │
   └────┬─────┘
        ▼
  Knowledge Graph
        │
        ▼
  LightRAG Engine
        │
        ▼
   Streamlit UI
        │
        ▼
   User Query
        │
        ▼
 Hybrid Retrieval
   + KG Search
        │
        ▼
  Gemini Flash
        │
        ▼
     Answer
```
""")

    st.divider()

    # Retrieval mode
    retrieval_mode = st.selectbox(
        "Retrieval mode",
        options=["hybrid", "local", "global", "naive"],
        index=0,
        help=(
            "hybrid = vector + KG  |  local = vector only  |  "
            "global = KG only  |  naive = simple semantic"
        ),
    )

    st.divider()

    # Ingest button
    st.subheader("📂 Ingest Documents")
    docs_dir = Path("data/documents")
    doc_files = list(docs_dir.glob("*")) if docs_dir.exists() else []
    st.caption(f"{len(doc_files)} file(s) in `data/documents/`")

    if st.button("▶ Run Ingestion Pipeline", use_container_width=True):
        with st.spinner("Ingesting … this may take a few minutes."):
            try:
                from ingest import ingest_documents
                run_async(ingest_documents())
                st.success("✅ Ingestion complete!")
                # Clear cached RAG so it picks up new storage
                load_rag.clear()
            except Exception as exc:
                st.error(f"Ingestion failed:\n{exc}")

    st.divider()

    if st.button("🗑 Clear chat history", use_container_width=True):
        st.session_state.messages = []
        st.rerun()


# ------------------------------------------------------------------
# Main area
# ------------------------------------------------------------------

st.title("🔍 LightRAG + Gemini Assistant")
st.caption(
    "Powered by BGE-small embeddings · Gemini 2.0 Flash · "
    "LightRAG knowledge-graph retrieval"
)

# Initialise chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Render existing messages (top → bottom)
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
query = st.chat_input("Ask a question about your documents …")

if query:
    # Show user message immediately
    st.session_state.messages.append({"role": "user", "content": query})
    with st.chat_message("user"):
        st.markdown(query)

    # Generate answer
    with st.chat_message("assistant"):
        with st.spinner("Retrieving from vector DB + knowledge graph …"):
            try:
                from lightrag import QueryParam

                rag = load_rag()
                answer = run_async(
                    rag.aquery(
                        query,
                        param=QueryParam(mode=retrieval_mode),
                    )
                )

                if not answer or not answer.strip():
                    answer = (
                        "I couldn't find a relevant answer in the indexed documents. "
                        "Please make sure documents are ingested first (sidebar → Run Ingestion Pipeline)."
                    )

            except Exception as exc:
                answer = f"⚠️ Error during retrieval:\n\n```\n{exc}\n```"

        st.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})
