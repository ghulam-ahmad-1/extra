# LightRAG + Gemini RAG System

A full Retrieval-Augmented Generation pipeline combining a **local knowledge graph** (LightRAG) with **BGE-small embeddings** and **Gemini 2.0 Flash**.

## Pipeline

```
PDF
 │
 ▼
Docling / MinerU  ←  high-fidelity PDF parsing (OCR + table extraction)
 │
 ▼
Markdown
 │
 ▼
Chunking  (1200-char windows, 200-char overlap)
 │
 ┌────────────────┴────────────────┐
 ▼                                 ▼
BGE-small-en-v1.5            Gemini 2.0 Flash
 ▼                                 ▼
Vector Embeddings         Entity Extraction
 ▼                                 ▼
Vector DB              Relationship Extraction
 │                                 │
 └────────────────┬────────────────┘
                  ▼
           Knowledge Graph
                  │
                  ▼
           LightRAG Engine
                  │
                  ▼
            Streamlit UI
                  │
                  ▼
            User Query
                  │
                  ▼
    Hybrid Retrieval + KG Search
                  │
                  ▼
           Gemini 2.0 Flash
                  │
                  ▼
                Answer
```

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Add your Gemini API key
Edit `.env`:
```
GEMINI_API_KEY=your_key_here
```
Get a free key at https://aistudio.google.com/apikey

### 3. Add documents
Place PDF (or DOCX, PPTX, HTML, MD, TXT) files in:
```
data/documents/
```

### 4. Ingest documents
```bash
python ingest.py
```
This runs the full pipeline: PDF → Markdown → Chunks → Embeddings + KG.  
Re-running is safe — already-indexed files are skipped.

### 5. Launch the UI
```bash
streamlit run app.py
```

You can also trigger ingestion from the Streamlit sidebar without leaving the UI.

## Project structure
```
lightrag-rag/
├── app.py              # Streamlit UI
├── ingest.py           # Ingestion pipeline (PDF → KG + vectors)
├── rag_engine.py       # LightRAG engine, BGE-small, Gemini LLM
├── requirements.txt
├── .env                # GEMINI_API_KEY
├── data/
│   └── documents/      # Drop your PDFs here
└── storage/            # LightRAG persists KG + vectors here
```

## Retrieval modes (selectable in sidebar)
| Mode | Description |
|------|-------------|
| **hybrid** | Vector similarity + knowledge-graph traversal (recommended) |
| local | Vector similarity only |
| global | Knowledge-graph traversal only |
| naive | Simple semantic search (no KG) |
