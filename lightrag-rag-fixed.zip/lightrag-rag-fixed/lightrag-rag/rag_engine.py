"""
rag_engine.py
-------------
Core LightRAG engine wired to:
  - BGE-small-en-v1.5  (local embeddings, 384-dim)
  - Gemini Flash        (LLM for entity/relationship extraction + answering)
"""

import os
import asyncio
import numpy as np

from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import google.generativeai as genai

from lightrag import LightRAG
from lightrag.utils import EmbeddingFunc

load_dotenv()

WORKING_DIR = "./storage"

# ------------------------------------------------------------------
# Gemini client setup
# ------------------------------------------------------------------

_api_key = os.getenv("GEMINI_API_KEY")
if not _api_key:
    raise EnvironmentError(
        "GEMINI_API_KEY is not set. "
        "Add it to your .env file: GEMINI_API_KEY=your_key_here"
    )

genai.configure(api_key=_api_key)

# ------------------------------------------------------------------
# Local Embedding Model  (BGE-small → 384 dimensions)
# ------------------------------------------------------------------

_embedding_model = None  # loaded lazily once


def _get_embedding_model() -> SentenceTransformer:
    global _embedding_model
    if _embedding_model is None:
        print("[rag_engine] Loading BGE-small embedding model …")
        _embedding_model = SentenceTransformer("BAAI/bge-small-en-v1.5")
    return _embedding_model


async def embedding_func(texts: list[str]) -> np.ndarray:
    """
    Wraps the synchronous SentenceTransformer in an executor so the
    async event loop is never blocked.
    """
    loop = asyncio.get_event_loop()
    model = _get_embedding_model()

    def _encode():
        return model.encode(
            texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )

    embeddings = await loop.run_in_executor(None, _encode)
    return embeddings  # shape: (len(texts), 384)


# ------------------------------------------------------------------
# Gemini LLM  (entity/relationship extraction + query answering)
# ------------------------------------------------------------------

async def llm_model_func(
    prompt: str,
    system_prompt: str | None = None,
    history_messages: list[dict] | None = None,
    **kwargs,
) -> str:
    """
    Async Gemini Flash wrapper compatible with LightRAG's llm_model_func
    signature.  Combines system prompt, history, and current prompt into
    a single contents string (Gemini Flash does not have a separate system
    role in the basic generate_content API).
    """
    if history_messages is None:
        history_messages = []

    parts: list[str] = []

    if system_prompt:
        parts.append(system_prompt)

    for msg in history_messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        parts.append(f"{role}: {content}")

    parts.append(f"user: {prompt}")

    combined = "\n".join(parts)

    # Run the blocking Gemini call in a thread executor
    loop = asyncio.get_event_loop()

    def _call_gemini():
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(combined)
        return response.text

    text = await loop.run_in_executor(None, _call_gemini)
    return text


# ------------------------------------------------------------------
# Chunking helper
# ------------------------------------------------------------------

def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 200) -> list[str]:
    """
    Splits *text* into overlapping chunks of roughly *chunk_size* characters.
    Overlap ensures entities that span a chunk boundary are captured.
    LightRAG does its own internal chunking too, but pre-chunking large
    documents gives the KG extractor more focused context windows.
    """
    if len(text) <= chunk_size:
        return [text]

    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start += chunk_size - overlap

    return chunks


# ------------------------------------------------------------------
# RAG singleton factory
# ------------------------------------------------------------------

_rag_instance: LightRAG | None = None


async def get_rag() -> LightRAG:
    """
    Returns a fully-initialised LightRAG instance (singleton per process).
    BGE-small-en-v1.5 produces 384-dimensional embeddings.
    """
    global _rag_instance
    if _rag_instance is not None:
        return _rag_instance

    os.makedirs(WORKING_DIR, exist_ok=True)

    _rag_instance = LightRAG(
        working_dir=WORKING_DIR,
        llm_model_func=llm_model_func,
        embedding_func=EmbeddingFunc(
            embedding_dim=384,      # ← BGE-small is 384, NOT 768
            max_token_size=512,
            func=embedding_func,
        ),
    )

    await _rag_instance.initialize_storages()
    return _rag_instance
