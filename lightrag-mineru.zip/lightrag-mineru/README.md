# LightRAG · MinerU · Qwen — Local RAG System

A fully **local** Retrieval-Augmented Generation system.  
No cloud LLM. No API key. Everything runs on your own machine.

---

## Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                         INGESTION                               │
│                                                                 │
│   ┌──────┐                                                      │
│   │ PDF  │  (drop files into data/documents/)                  │
│   └──┬───┘                                                      │
│      │                                                          │
│      ▼                                                          │
│  ┌──────────────────────────────┐                               │
│  │   MinerU  (magic-pdf)        │                               │
│  │   • Layout detection         │                               │
│  │   • OCR via PaddleOCR        │                               │
│  │   • Table / formula extract  │                               │
│  └──────────────┬───────────────┘                               │
│                 │                                               │
│                 ▼                                               │
│            Markdown                                             │
│                 │                                               │
│                 ▼                                               │
│   ┌─────────────────────────┐                                   │
│   │  Chunking               │                                   │
│   │  1200-char windows      │                                   │
│   │  200-char overlap       │                                   │
│   └──────────┬──────────────┘                                   │
│              │                                                  │
│       ┌──────┴──────┐                                           │
│       ▼             ▼                                           │
│  ┌──────────┐  ┌───────────────────┐                           │
│  │BGE-small │  │  Qwen  (local)    │                           │
│  │en-v1.5   │  │  http://localhost │                           │
│  │(384-dim) │  │  no API key       │                           │
│  └────┬─────┘  └────────┬──────────┘                           │
│       │                 │                                       │
│       ▼                 ▼                                       │
│  ┌─────────┐   ┌─────────────────────┐                         │
│  │ Vector  │   │  Entity Extraction  │                         │
│  │Embeddings│  │  Relationship Graph │                         │
│  └────┬────┘   └──────────┬──────────┘                         │
│       │                   │                                     │
│       ▼                   ▼                                     │
│  ┌─────────┐      ┌───────────────┐                            │
│  │Vector DB│      │ Knowledge     │                            │
│  │(nano-   │      │ Graph  (KG)   │                            │
│  │ vectordb│      └───────┬───────┘                            │
│  └────┬────┘              │                                     │
│       └─────────┬─────────┘                                     │
│                 ▼                                               │
│         LightRAG Storage  (./storage/)                          │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          QUERY                                  │
│                                                                 │
│   Streamlit UI                                                  │
│       │                                                         │
│       ▼                                                         │
│   User Query                                                    │
│       │                                                         │
│       ▼                                                         │
│  ┌─────────────────────────────────────┐                        │
│  │  LightRAG Engine                    │                        │
│  │  Hybrid Retrieval                   │                        │
│  │  • Vector similarity (BGE-small)    │                        │
│  │  • Knowledge Graph traversal        │                        │
│  └──────────────────┬──────────────────┘                        │
│                     │                                           │
│                     ▼                                           │
│             Qwen  (local LLM)                                   │
│             Generates final answer                              │
│                     │                                           │
│                     ▼                                           │
│                  Answer                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## Prerequisites

| Component | What it does | Notes |
|-----------|-------------|-------|
| **MinerU** (`magic-pdf`) | PDF → Markdown | Needs model weights (auto-downloaded on first run) |
| **BGE-small-en-v1.5** | Local text embeddings | Auto-downloaded by `sentence-transformers` |
| **Qwen** | LLM for KG extraction + answering | Must be running locally before you start |
| **LightRAG** | KG + vector hybrid retrieval | Pure Python, no external service |
| **Streamlit** | Chat UI | |

---

## Setup

### 1. Install Python dependencies
```bash
pip install -r requirements.txt
```

> MinerU will download its layout/OCR model weights (~2 GB) on first run.

### 2. Start your Qwen server

Make sure your Qwen instance is running and serving an **OpenAI-compatible** `/v1` API.  
Example with Ollama:
```bash
ollama serve          # starts on http://localhost:11434
ollama pull qwen      # download the model if needed
```

Or with vLLM / llama.cpp / LM Studio — any server that exposes `/v1/chat/completions`.

### 3. Configure the server URL

Edit `.env` to point to your Qwen server:
```env
QWEN_BASE_URL=http://localhost:11434/v1
QWEN_MODEL=qwen
OPENAI_API_KEY=          # leave blank — not needed for local servers
```

Common ports:
| Server | Default URL |
|--------|------------|
| Ollama | `http://localhost:11434/v1` |
| LM Studio | `http://localhost:1234/v1` |
| vLLM | `http://localhost:8000/v1` |
| llama.cpp server | `http://localhost:8080/v1` |

### 4. Add your documents

Drop PDF files (also `.txt` / `.md`) into:
```
data/documents/
```

### 5. Run ingestion

```bash
python ingest.py
```

This runs the full pipeline:  
PDF → MinerU → Markdown → Chunks → BGE embeddings + Qwen KG extraction → LightRAG storage.

Re-running is **safe** — already-indexed files are skipped automatically.

### 6. Launch the UI

```bash
streamlit run app.py
```

You can also trigger ingestion directly from the sidebar inside the app.

---

## Project structure

```
lightrag-mineru/
├── app.py                  # Streamlit chat UI
├── ingest.py               # Ingestion pipeline (MinerU → LightRAG)
├── rag_engine.py           # LightRAG + BGE-small + Qwen wiring
├── requirements.txt
├── .env                    # QWEN_BASE_URL, QWEN_MODEL (no API key needed)
├── data/
│   └── documents/          # ← drop your PDFs here
└── storage/                # LightRAG persists KG + vector DB here
```

---

## Retrieval modes

Select in the sidebar:

| Mode | Description |
|------|-------------|
| **hybrid** | Vector similarity + KG traversal — best overall quality |
| **local** | Vector similarity only (faster) |
| **global** | Knowledge-graph traversal only |
| **naive** | Simple semantic search, no KG |

---

## Troubleshooting

**`Connection refused` when querying**  
→ Your Qwen server isn't running. Start it first, then retry.

**Empty answers after ingestion**  
→ Check `storage/` exists and contains files. Re-run `python ingest.py`.

**MinerU model download on first run**  
→ Normal. MinerU downloads layout detection weights (~2 GB) once to `~/.cache/`.

**`embedding_dim` mismatch error**  
→ Make sure you haven't changed `embedding_dim` in `rag_engine.py`. BGE-small is always 384.
