"""
rag_engine.py
-------------
LightRAG engine wired to:
  • BGE-small-en-v1.5  — local embeddings (384-dim)
  • Qwen (local server) — LLM served via OpenAI-compatible API
                          at http://localhost:11434/v1  (or as set in .env)
                          No API key required.
"""

import os
import asyncio

import numpy as np
import httpx
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

from lightrag import LightRAG
from lightrag.utils import EmbeddingFunc

load_dotenv()

WORKING_DIR = "./storage"

# URL of your local Qwen server  (OpenAI-compatible /v1 endpoint)
QWEN_BASE_URL = os.getenv("QWEN_BASE_URL", "http://localhost:11434/v1")
QWEN_MODEL    = os.getenv("QWEN_MODEL",    "qwen")


# ──────────────────────────────────────────────────────────────────
# BGE-small embedding model  (384-dim, runs 100 % locally)
# ──────────────────────────────────────────────────────────────────

_embedding_model: SentenceTransformer | None = None


def _get_embedding_model() -> SentenceTransformer:
    global _embedding_model
    if _embedding_model is None:
        print("[rag_engine] Loading BAAI/bge-small-en-v1.5 …")
        _embedding_model = SentenceTransformer("BAAI/bge-small-en-v1.5")
    return _embedding_model


async def embedding_func(texts: list[str]) -> np.ndarray:
    """
    Async wrapper — offloads the synchronous encode() to a thread
    so the event loop is never blocked.
    """
    loop = asyncio.get_event_loop()
    model = _get_embedding_model()

    def _encode():
        return model.encode(
            texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )

    return await loop.run_in_executor(None, _encode)   # shape: (N, 384)


# ──────────────────────────────────────────────────────────────────
# Qwen LLM  (local OpenAI-compatible server, no API key)
# ──────────────────────────────────────────────────────────────────

async def llm_model_func(
    prompt: str,
    system_prompt: str | None = None,
    history_messages: list[dict] | None = None,
    **kwargs,
) -> str:
    """
    Async LLM function for LightRAG.
    Calls the local Qwen server at QWEN_BASE_URL using the
    OpenAI /v1/chat/completions API.  No API key is sent.
    """
    if history_messages is None:
        history_messages = []

    messages: list[dict] = []

    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})

    for msg in history_messages:
        messages.append({
            "role":    msg.get("role", "user"),
            "content": msg.get("content", ""),
        })

    messages.append({"role": "user", "content": prompt})

    payload = {
        "model":       QWEN_MODEL,
        "messages":    messages,
        "temperature": 0.1,          # low temp → consistent KG extraction
        "max_tokens":  2048,
    }

    # httpx async client — no API key header needed
    async with httpx.AsyncClient(timeout=120.0) as client:
        response = await client.post(
            f"{QWEN_BASE_URL}/chat/completions",
            json=payload,
            headers={"Content-Type": "application/json"},
        )
        response.raise_for_status()
        data = response.json()

    return data["choices"][0]["message"]["content"]


# ──────────────────────────────────────────────────────────────────
# Chunking helper
# ──────────────────────────────────────────────────────────────────

def chunk_text(
    text: str,
    chunk_size: int = 1200,
    overlap:    int = 200,
) -> list[str]:
    """
    Splits text into overlapping windows.
    • chunk_size: characters per chunk
    • overlap:    characters shared between consecutive chunks
                  (keeps entities that span a boundary intact)
    """
    if len(text) <= chunk_size:
        return [text]

    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start += chunk_size - overlap
    return chunks


# ──────────────────────────────────────────────────────────────────
# LightRAG singleton
# ──────────────────────────────────────────────────────────────────

_rag_instance: LightRAG | None = None


async def get_rag() -> LightRAG:
    """
    Returns an initialised LightRAG instance (one per process).
    BGE-small → 384-dim  |  Qwen local server → LLM
    """
    global _rag_instance
    if _rag_instance is not None:
        return _rag_instance

    os.makedirs(WORKING_DIR, exist_ok=True)

    _rag_instance = LightRAG(
        working_dir=WORKING_DIR,
        llm_model_func=llm_model_func,
        embedding_func=EmbeddingFunc(
            embedding_dim=384,   # BGE-small-en-v1.5 → 384 dims
            max_token_size=512,
            func=embedding_func,
        ),
    )

    await _rag_instance.initialize_storages()
    return _rag_instance
