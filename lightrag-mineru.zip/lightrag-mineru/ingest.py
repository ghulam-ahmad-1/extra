"""
ingest.py
---------
Full ingestion pipeline:

  PDF
   │
   ▼
  MinerU (magic-pdf)          ← high-fidelity PDF → Markdown
   │
   ▼
  Markdown
   │
   ▼
  Chunking  (1200-char, 200 overlap)
   │
   ┌──────────┴──────────┐
   ▼                     ▼
BGE-small            Qwen (local)
   ▼                     ▼
Vector Embeddings   Entity Extraction
   ▼                     ▼
Vector DB       Relationship Extraction
   │                     │
   └──────────┬──────────┘
              ▼
        Knowledge Graph
              │
              ▼
        LightRAG storage

Run once before launching the app:
    python ingest.py
"""

import asyncio
import json
import os
import tempfile
from pathlib import Path

from rag_engine import get_rag, chunk_text

# ──────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────

DOCS_DIR    = Path("data/documents")
STORAGE_DIR = Path("storage")
LOG_FILE    = STORAGE_DIR / "ingested_files.json"

SUPPORTED = {".pdf", ".txt", ".md"}   # MinerU handles PDF; txt/md go in directly


# ──────────────────────────────────────────────────────────────────
# Idempotency log
# ──────────────────────────────────────────────────────────────────

def load_log() -> set[str]:
    if LOG_FILE.exists():
        with open(LOG_FILE) as f:
            return set(json.load(f))
    return set()


def save_log(names: set[str]) -> None:
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "w") as f:
        json.dump(sorted(names), f, indent=2)


# ──────────────────────────────────────────────────────────────────
# MinerU PDF → Markdown
# ──────────────────────────────────────────────────────────────────

def pdf_to_markdown_mineru(pdf_path: Path) -> str:
    """
    Convert a PDF file to Markdown using MinerU (magic-pdf).

    MinerU pipeline:
      1. Reads PDF pages
      2. Runs layout detection (bounding-box models)
      3. Applies OCR if needed (PaddleOCR under the hood)
      4. Extracts tables, formulas, figures
      5. Exports clean Markdown

    Returns the full Markdown string.
    """
    try:
        from magic_pdf.data.data_reader_writer import FileBasedDataWriter
        from magic_pdf.data.dataset import PymuPDFDataset
        from magic_pdf.model.doc_analyze_by_custom_model import doc_analyze
        from magic_pdf.config.enums import SupportedPdfParseMethod
        from magic_pdf.pipe.UNIPipe import UNIPipe

        with tempfile.TemporaryDirectory() as tmp:
            out_dir  = Path(tmp) / "output"
            img_dir  = out_dir / "images"
            out_dir.mkdir(parents=True)
            img_dir.mkdir(parents=True)

            writer     = FileBasedDataWriter(str(out_dir))
            img_writer = FileBasedDataWriter(str(img_dir))

            pdf_bytes = pdf_path.read_bytes()
            ds        = PymuPDFDataset(pdf_bytes)

            # AUTO mode: MinerU chooses OCR or text-layer automatically
            pipe = UNIPipe(
                pdf_bytes,
                {"_pdf_type": "", "model_list": []},
                image_writer=img_writer,
            )
            pipe.pipe_classify()
            pipe.pipe_analyze()
            pipe.pipe_parse()

            md_content = pipe.pipe_mk_markdown(
                img_dir=str(img_dir),
                drop_mode="none",
            )
            return md_content if isinstance(md_content, str) else "\n".join(md_content)

    except Exception as exc:
        # Graceful fallback: use PyMuPDF plain-text extraction
        print(f"  [!] MinerU pipeline failed ({exc}), falling back to PyMuPDF text …")
        return _pymupdf_fallback(pdf_path)


def _pymupdf_fallback(pdf_path: Path) -> str:
    """Plain-text extraction using PyMuPDF as a last resort."""
    try:
        import fitz  # PyMuPDF
        doc   = fitz.open(str(pdf_path))
        pages = [page.get_text("text") for page in doc]
        doc.close()
        return "\n\n".join(pages)
    except Exception as exc2:
        raise RuntimeError(f"Both MinerU and PyMuPDF failed for {pdf_path.name}: {exc2}")


# ──────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────

async def ingest_documents() -> None:
    if not DOCS_DIR.exists() or not any(DOCS_DIR.iterdir()):
        print(f"[ingest] No documents found in '{DOCS_DIR}/'. Nothing to do.")
        return

    rag      = await get_rag()
    ingested = load_log()
    files    = sorted(f for f in DOCS_DIR.iterdir()
                      if f.is_file() and f.suffix.lower() in SUPPORTED)

    if not files:
        print(f"[ingest] No supported files ({', '.join(SUPPORTED)}) in '{DOCS_DIR}/'.")
        return

    newly_done: list[str] = []

    for file in files:
        if file.name in ingested:
            print(f"[ingest] Skip (already indexed): {file.name}")
            continue

        print(f"\n[ingest] ══ Processing: {file.name}")

        # ── Step 1: PDF → Markdown ────────────────────────────────
        if file.suffix.lower() == ".pdf":
            print("  [1/3] MinerU: PDF → Markdown …")
            try:
                markdown = pdf_to_markdown_mineru(file)
            except Exception as exc:
                print(f"  [!] Conversion failed: {exc}")
                continue
        else:
            print("  [1/3] Reading plain text / Markdown …")
            markdown = file.read_text(encoding="utf-8", errors="replace")

        if not markdown.strip():
            print("  [!] Empty output — skipping.")
            continue

        print(f"  [1/3] Markdown length: {len(markdown):,} chars")

        # ── Step 2: Chunking ──────────────────────────────────────
        print("  [2/3] Chunking …")
        chunks = chunk_text(markdown, chunk_size=1200, overlap=200)
        print(f"  [2/3] {len(chunks)} chunk(s)")

        # ── Step 3: LightRAG insert ────────────────────────────────
        # Internally: BGE-small → vectors + Qwen → entities/relations → KG
        print("  [3/3] Inserting into LightRAG (embeddings + KG) …")
        try:
            for i, chunk in enumerate(chunks, 1):
                await rag.ainsert(chunk)
                if i % 5 == 0 or i == len(chunks):
                    print(f"  [3/3] {i}/{len(chunks)} chunks done …")
        except Exception as exc:
            print(f"  [!] Insert error: {exc}")
            continue

        newly_done.append(file.name)
        ingested.add(file.name)
        print(f"  ✓ Indexed: {file.name}")

    save_log(ingested)

    if newly_done:
        print(f"\n[ingest] ✅ Done. Indexed {len(newly_done)} new file(s):")
        for n in newly_done:
            print(f"    • {n}")
    else:
        print("\n[ingest] ✅ Nothing new to index.")


if __name__ == "__main__":
    asyncio.run(ingest_documents())
