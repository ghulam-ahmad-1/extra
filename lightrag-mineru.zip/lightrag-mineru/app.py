"""
app.py
------
Streamlit chat UI for the LightRAG + MinerU + Qwen pipeline.

Launch:
    streamlit run app.py
"""

import asyncio
import os
from pathlib import Path

import streamlit as st

# ──────────────────────────────────────────────────────────────────
# Page config  (must be the first Streamlit call)
# ──────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="LightRAG · MinerU · Qwen",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ──────────────────────────────────────────────────────────────────
# Asyncio helper
# Streamlit's internal thread already has an event loop running.
# asyncio.run() raises RuntimeError in that context, so we reuse
# or create a loop manually.
# ──────────────────────────────────────────────────────────────────

def run_async(coro):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)


# ──────────────────────────────────────────────────────────────────
# Cached RAG loader  (initialised once per Streamlit session)
# ──────────────────────────────────────────────────────────────────

@st.cache_resource(show_spinner="🔧 Loading LightRAG engine …")
def load_rag():
    from rag_engine import get_rag
    return run_async(get_rag())


# ──────────────────────────────────────────────────────────────────
# Sidebar
# ──────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("🧠 LightRAG")
    st.caption("MinerU · BGE-small · Qwen (local)")

    st.divider()

    # ── Workflow diagram ──────────────────────────────────────────
    st.subheader("📐 Pipeline")
    st.markdown("""
```
         PDF
          │
          ▼
   MinerU (magic-pdf)
   • Layout detection
   • OCR (PaddleOCR)
   • Table / formula extract
          │
          ▼
       Markdown
          │
          ▼
       Chunking
    (1200 chars / 200 overlap)
          │
     ┌────┴────┐
     ▼         ▼
 BGE-small   Qwen (local)
     ▼         ▼
  Vector   Entity Extraction
Embeddings      ▼
     ▼    Relationship
 Vector       Extraction
   DB         │
     └────┬───┘
          ▼
    Knowledge Graph
          │
          ▼
    LightRAG Engine
          │
          ▼
     Streamlit UI
          │
          ▼
      User Query
          │
          ▼
  Hybrid Retrieval
  (Vector DB + KG)
          │
          ▼
   Qwen (local LLM)
          │
          ▼
        Answer
```
""")

    st.divider()

    # ── Retrieval mode ────────────────────────────────────────────
    retrieval_mode = st.selectbox(
        "Retrieval mode",
        ["hybrid", "local", "global", "naive"],
        index=0,
        help=(
            "hybrid = vector + KG  |  local = vector only  |  "
            "global = KG only  |  naive = semantic only"
        ),
    )

    # ── Qwen server info (read from .env) ─────────────────────────
    from dotenv import load_dotenv
    load_dotenv()
    qwen_url   = os.getenv("QWEN_BASE_URL", "http://localhost:11434/v1")
    qwen_model = os.getenv("QWEN_MODEL",    "qwen")
    st.divider()
    st.subheader("🖥️ Local LLM Server")
    st.code(f"URL:   {qwen_url}\nModel: {qwen_model}", language="text")

    st.divider()

    # ── Ingestion ─────────────────────────────────────────────────
    st.subheader("📂 Ingest Documents")
    docs_dir  = Path("data/documents")
    doc_files = [f for f in docs_dir.glob("*") if f.is_file()] if docs_dir.exists() else []
    st.caption(f"{len(doc_files)} file(s) in `data/documents/`")

    if doc_files:
        with st.expander("Files found"):
            for f in doc_files:
                st.text(f"• {f.name}")

    if st.button("▶ Run Ingestion Pipeline", use_container_width=True):
        with st.spinner("Running MinerU → Chunking → LightRAG …"):
            try:
                from ingest import ingest_documents
                run_async(ingest_documents())
                st.success("✅ Ingestion complete!")
                load_rag.clear()          # reload RAG to pick up new vectors/KG
            except Exception as exc:
                st.error(f"Ingestion error:\n\n```\n{exc}\n```")

    st.divider()
    if st.button("🗑 Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()


# ──────────────────────────────────────────────────────────────────
# Main chat area
# ──────────────────────────────────────────────────────────────────

st.title("🔍 LightRAG Assistant")
st.caption(
    f"PDF parsing: **MinerU** · Embeddings: **BGE-small-en-v1.5** · "
    f"LLM: **Qwen** (local, no API key)"
)

# Initialise history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Render history  (top → bottom)
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
query = st.chat_input("Ask something about your documents …")

if query:
    # Show user bubble immediately
    st.session_state.messages.append({"role": "user", "content": query})
    with st.chat_message("user"):
        st.markdown(query)

    # Generate answer
    with st.chat_message("assistant"):
        with st.spinner(f"Retrieving ({retrieval_mode}) + generating with Qwen …"):
            try:
                from lightrag import QueryParam

                rag    = load_rag()
                answer = run_async(
                    rag.aquery(query, param=QueryParam(mode=retrieval_mode))
                )

                if not answer or not answer.strip():
                    answer = (
                        "⚠️ No relevant content found. "
                        "Make sure you've run the ingestion pipeline first "
                        "(sidebar → **▶ Run Ingestion Pipeline**)."
                    )

            except Exception as exc:
                answer = f"⚠️ Error:\n\n```\n{exc}\n```"

        st.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})
